<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="maachudri" tilewidth="800" tileheight="450" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="800" height="450" source="../Downloads/terrain.png"/>
 </tile>
 <tile id="1">
  <image width="800" height="450" source="../Downloads/Untitled-1 (1).png"/>
 </tile>
 <tile id="2">
  <image width="800" height="450" source="../Downloads/world.png"/>
 </tile>
</tileset>
