package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.screens.Mainmenuscreen;
import com.mygdx.game.screens.gscreen;

public class AssP1  extends Game  {
	public SpriteBatch batch;
	public int p1Tank;
	public int p2Tank;
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		setScreen(new Mainmenuscreen(this));

	}

	@Override
	public void render () {
		super.render();

	}

	@Override
	public void dispose () {

	}
}
