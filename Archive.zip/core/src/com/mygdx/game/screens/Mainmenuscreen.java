package com.mygdx.game.screens;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.AssP1;

public class Mainmenuscreen implements Screen {
    AssP1 game;
    Texture main_menu,exit,play;
    public Mainmenuscreen(AssP1 game){
        this.game=game;

    }

    @Override
    public void show() {
        main_menu=new Texture("menu_main.png");
        exit=new Texture("exit_main_menu.png");
        play=new Texture("play_main_menu.png");
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        if (Gdx.input.getX()>45&&Gdx.input.getX()<165&&Gdx.input.getY()>148&&Gdx.input.getY()<199){
            game.batch.draw(play,0,0,800,450);
            if(Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Secondscreen(game));
            }
        }
        else if(Gdx.input.getY()>148&&Gdx.input.getY()<199&&Gdx.input.getX()>638&&Gdx.input.getX()<755){
            game.batch.draw(exit,0,0,800,450);
            if(Gdx.input.isTouched()){
                Gdx.app.exit();
            }
        }
        else {
            game.batch.draw(main_menu,0,0,800,450);
        }
        game.batch.end();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
