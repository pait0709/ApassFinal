package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.AssP1;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.maps.tiled.renderers.*;
import com.mygdx.game.Sprites.Tank;
import com.mygdx.game.Sprites.Tank2;
import com.mygdx.game.Utils.TiledObjectUtil;

public class gscreen implements Screen {
    AssP1 game;
    Texture gscreen,pause_gscreen;
    private OrthographicCamera gamecam;
    private TmxMapLoader mapLoader;
    private TextureAtlas atlas;
    private TiledMap map;
    private Tank player;
    private Tank2 player2;
    private OrthogonalTiledMapRenderer renderer;
    private World world;
    private Box2DDebugRenderer b2dr;
    public gscreen(AssP1 game){
        atlas= new TextureAtlas("Pait.txt");
        gamecam=new OrthographicCamera();
        this.game=game;
        mapLoader=new TmxMapLoader();
        map=mapLoader.load("Final_map.tmx");
        renderer=new OrthogonalTiledMapRenderer(map);
        world=new World(new Vector2(0,-10),true);
        b2dr=new Box2DDebugRenderer();
        gamecam.setToOrtho(false,800,450);
        TiledObjectUtil.parseTiledObjectLayer(world,map.getLayers().get(1).getObjects());
//        atlas=new TextureAtlas("tank 1 sprite sheet.pack");//Inside the ingame constructir
        player=new Tank(world,this);//parameter changes of player in ingame class
        player2=new Tank2(world,this);

    }

    public TextureAtlas getAtlas () {
        return atlas;
    }

    @Override
    public void show() {
//        gscreen=new Texture("gscreen.png");
        pause_gscreen=new Texture("pause_gscreen.png");
    }
    public void handleInput(float dt){
            if (Gdx.input.isKeyPressed(Input.Keys.A) && player.b2body.getLinearVelocity().x >= -2)
                player.b2body.applyLinearImpulse(new Vector2(-25f, 0), player.b2body.getWorldCenter(), true);
            player.f.changeFuel(dt);
            if (Gdx.input.isKeyPressed(Input.Keys.D) && player.b2body.getLinearVelocity().x <= 2)
                player.b2body.applyLinearImpulse(new Vector2(25f, 0), player.b2body.getWorldCenter(), true);
            player.f.changeFuel(dt);
            if (Gdx.input.isKeyPressed(Input.Keys.S)) {
                player.b2body.setLinearVelocity(0, 0);
            }

            if (Gdx.input.isKeyPressed(Input.Keys.J) && player2.b2body.getLinearVelocity().x >= -2)
                player2.b2body.applyLinearImpulse(new Vector2(-25f, 0), player2.b2body.getWorldCenter(), true);
            player2.f.changeFuel(dt);

            if (Gdx.input.isKeyPressed(Input.Keys.L) && player2.b2body.getLinearVelocity().x <= 2)
                player2.b2body.applyLinearImpulse(new Vector2(25f, 0), player2.b2body.getWorldCenter(), true);
            player2.f.changeFuel(dt);
            if (Gdx.input.isKeyPressed(Input.Keys.K)) {
                player2.b2body.setLinearVelocity(0, 0);
            }

    }
    public void update(float dt){
        renderer.setView(gamecam);
        world.step(1/60f,6,2);
        player.update(dt);//in the update function
        player2.update(dt);
        handleInput(dt);
        gamecam.update();


    }
    @Override
    public void render(float delta) {
        update(delta);
//        ScreenUtils.clear(0, 0, 0, 1);
        Gdx.gl.glClearColor(0,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        renderer.render();
        b2dr.render(world,gamecam.combined);
        game.batch.setProjectionMatrix(gamecam.combined);
        game.batch.begin();
        player.draw(game.batch);
        player2.draw(game.batch);
//        renderer.render();
        if (Gdx.input.getX()>14&&Gdx.input.getX()<45&&Gdx.input.getY()>22&&Gdx.input.getY()<68){
            game.batch.draw(pause_gscreen,0,0,800,450);
            if(Gdx.input.isTouched()) {
                game.setScreen(new pause(game));
            }
        }
//        else {
//            game.batch.draw(gscreen,0,0,800,450);
//        }
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        world.dispose();
        b2dr.dispose();
    }

}
