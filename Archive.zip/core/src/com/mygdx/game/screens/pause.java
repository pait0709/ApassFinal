package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.AssP1;

public class pause implements Screen {
    AssP1 game;
    Texture pause, resume,save,exit;
    public pause(AssP1 game){
        this.game=game;
    }
    @Override
    public void show() {
        pause= new Texture("pause_screen.png");
        resume=new Texture("resume_pause.png");
        save=new Texture("save_pause.png");
        exit= new Texture("exit_pause.png");
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        if(Gdx.input.getX()>514&&Gdx.input.getX()<610&&Gdx.input.getY()>260&&Gdx.input.getY()<286){
            game.batch.draw(save,0,0,800,450);
            if(Gdx.input.isTouched()){
                game.setScreen(new Mainmenuscreen(game));
            }
        } else if (Gdx.input.getX()>514&&Gdx.input.getX()<610&&Gdx.input.getY()>345&&Gdx.input.getY()<372){
            game.batch.draw(exit,0,0,800,450);
            if(Gdx.input.isTouched()){
                game.setScreen(new Mainmenuscreen(game));
            }



        } else if(Gdx.input.getX()>512&&Gdx.input.getX()<664&&Gdx.input.getY()>173&&Gdx.input.getY()<200){
            game.batch.draw(resume,0,0,800,450);
            if(Gdx.input.isTouched()){
                game.setScreen(new gscreen(game));
            }
        }
        else{
            game.batch.draw(pause,0,0,800,450);
        }
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
