package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.AssP1;

public class Tank_sel_screen implements Screen {
    AssP1 game;
    Animation move;
    float time_elap=0f;
    int selection=900;
    TextureRegion[] final_frames;
    Texture tanksel, select_tanksel,right_tanksel,left_tanksel;
    Texture[] tanks;
    public Tank_sel_screen(AssP1 game){
        this.game=game;

    }
    @Override
    public void show() {
        tanksel=new Texture("normal tanksel.png");
        select_tanksel=new Texture("selct__tanksel.png");
        right_tanksel=new Texture("rightselct__tanksel.png");
        left_tanksel=new Texture("leftselct__tanksel.png");
        tanks=new Texture[3];
        tanks[0]=new Texture("Tank1.png");
        tanks[1]=new Texture("Tank2.png");
        tanks[2]=new Texture("Tank3.png");

//        TextureRegion[][] frames=TextureRegion.split(new Texture("a2.png"),206,115);
//        final_frames=new TextureRegion[4];
//        for(int i=0;i<4;i++){
//            final_frames[i]=frames[0][i];
//        }
//        move=new Animation((1f/4f),final_frames);

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();

        if (Gdx.input.getX()>68&&Gdx.input.getX()<98&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
            game.batch.draw(left_tanksel,0,0,800,450);
            game.batch.draw(tanks[selection%3],51,110,252,232);
            if(Gdx.input.isTouched()) {
                try {
                    Thread.sleep(0xfa);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                int k=selection--;
                game.batch.draw(tanks[k%3],51,110,252,232);
            }
        }
        else if (Gdx.input.getX()>254&&Gdx.input.getX()<284&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
            game.batch.draw(right_tanksel,0,0,800,450);
            game.batch.draw(tanks[selection%3],51,110,252,232);
            if(Gdx.input.isTouched()) {
                try {
                    Thread.sleep(0xfa);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                int k=selection++;
                game.batch.draw(tanks[k%3],51,110,252,232);
            }
        }
        else if (Gdx.input.getX()>120&&Gdx.input.getX()<235&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
            game.batch.draw(select_tanksel,0,0,800,450);
            game.batch.draw(tanks[selection%3],51,110,252,232);
            if(Gdx.input.isTouched()) {
               game.p1Tank=selection%3;
               game.setScreen(new p2_tank_sel(game));

            }
        }
//        else if (Gdx.input.getX()>120&&Gdx.input.getX()<235&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
//            game.batch.draw(select_tanksel,0,0,800,450);
//            if(Gdx.input.isTouched()) {
//
//            }
//        }
        else {
            game.batch.draw(tanksel,0,0,800,450);
            game.batch.draw(tanks[selection%3],51,110,252,232);

        }
        game.batch.end();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
