package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.AssP1;

public class MainGamescreen implements Screen {

    AssP1 game;
    Texture img;
    Sprite sprite;
    public MainGamescreen(AssP1 game) {
        this.game=game;
    }
    @Override
    public void show() {
        img = new Texture("helloworld.png");
        sprite=new Sprite(img);
        sprite.setPosition((Gdx.graphics.getWidth()-img.getWidth())/2,(Gdx.graphics.getHeight()-img.getHeight())/2);

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        if(Gdx.input.isKeyPressed(Input.Keys.UP)) {
            sprite.setScale((0.5f));

        }
        else{
            sprite.setScale(1);

        }
        game.batch.draw(sprite, sprite.getX(), sprite.getY(), 0, 0, sprite.getWidth(), sprite.getHeight(), sprite.getScaleX(), sprite.getScaleY(), sprite.getRotation());
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        game.batch.dispose();
        img.dispose();
    }
}
