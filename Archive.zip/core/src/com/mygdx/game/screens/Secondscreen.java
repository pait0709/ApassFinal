package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.AssP1;

public class Secondscreen implements Screen {
    AssP1 game;
    Texture Sec, new_sec,load_sec,back_sec;
    public Secondscreen(AssP1 game){
        this.game=game;
    }
    @Override
    public void show() {
        Sec=new Texture("2nd screen.png");
        new_sec=new Texture("new_game_2nd screen.png");
        load_sec=new Texture("load_game_2nd screen.png");
        back_sec=new Texture("Back_2nd screen.png");
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        if (Gdx.input.getX()>45&&Gdx.input.getX()<275&&Gdx.input.getY()>210&&Gdx.input.getY()<260){
            game.batch.draw(new_sec,0,0,800,450);
            if(Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Tank_sel_screen(game));
            }
        }
        else if (Gdx.input.getX()>496&&Gdx.input.getX()<755&&Gdx.input.getY()>210&&Gdx.input.getY()<260){
            game.batch.draw(load_sec,0,0,800,450);
            if(Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new MainGamescreen(game));
            }
        }
        else if (Gdx.input.getX()>340&&Gdx.input.getX()<460&&Gdx.input.getY()>210&&Gdx.input.getY()<260){
            game.batch.draw(back_sec,0,0,800,450);
            if(Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Mainmenuscreen(game));
            }
        }
        else {
            game.batch.draw(Sec,0,0,800,450);
        }
        game.batch.end();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
