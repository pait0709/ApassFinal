package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.AssP1;

public class PvP implements Screen {
    AssP1 game;
    Texture normal,start;
    Texture[] tanks,tanks1;
    public PvP(AssP1 game){
        this.game=game;
    }

    @Override
    public void show() {
        normal=new Texture("PvP.png");
        start=new Texture("Start_PvP.png");
        tanks=new Texture[3];
        tanks1=new Texture[3];
        tanks[0]=new Texture("Tank1.png");
        tanks[1]=new Texture("Tank2.png");
        tanks[2]=new Texture("Tank3.png");
        tanks1[0]=new Texture("Tank11.png");
        tanks1[1]=new Texture("Tank22.png");
        tanks1[2]=new Texture("Tank33.png");
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();
        if(Gdx.input.getX()>361&&Gdx.input.getX()<460&&Gdx.input.getY()>218&&Gdx.input.getY()<252){
            game.batch.draw(start, 0, 0, 800, 450);
            game.batch.draw(tanks1[game.p2Tank], 500, 110, 252, 232);
            game.batch.draw(tanks[game.p1Tank], 72, 110, 252, 232);
            if(Gdx.input.isTouched()) {
                game.setScreen(new gscreen(game));
            }

        }
        else{
            game.batch.draw(normal, 0, 0, 800, 450);
            game.batch.draw(tanks1[game.p2Tank], 500, 110, 252, 232);
            game.batch.draw(tanks[game.p1Tank], 72, 110, 252, 232);
        }
        game.batch.end();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
