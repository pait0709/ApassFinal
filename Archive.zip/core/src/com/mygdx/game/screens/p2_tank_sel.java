package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.AssP1;
import org.w3c.dom.Text;

public class p2_tank_sel implements Screen {
    AssP1 game;
    Texture tanksel, select_tanksel,right_tanksel,left_tanksel;
    int selection=900;
    Texture[] tanks;
    public p2_tank_sel(AssP1 game){
        this.game=game;
    }
    @Override
    public void show() {
        tanksel=new Texture("p2tanksel.png");
        select_tanksel=new Texture("Select_p2tanksel.png");
        right_tanksel=new Texture("rightp2tanksel.png");
        left_tanksel=new Texture("leftp2tanksel.png");
        tanks=new Texture[3];
        tanks[0]=new Texture("Tank11.png");
        tanks[1]=new Texture("Tank22.png");
        tanks[2]=new Texture("Tank33.png");
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        game.batch.begin();


        if (Gdx.input.getX()>516&&Gdx.input.getX()<546&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
            game.batch.draw(left_tanksel,0,0,800,450);
            game.batch.draw(tanks[selection%3],500,110,252,232);
            if(Gdx.input.isTouched()) {
                try {
                    Thread.sleep(0xfa);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                int k=selection--;
                game.batch.draw(tanks[k%3],500,794,252,232);
            }
        }
        else if (Gdx.input.getX()>702&&Gdx.input.getX()<732&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
            game.batch.draw(right_tanksel,0,0,800,450);
            game.batch.draw(tanks[selection%3],500,110,252,232);
            if(Gdx.input.isTouched()) {
                try {
                    Thread.sleep(0xfa);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                int k=selection++;
                game.batch.draw(tanks[k%3],500,110,252,232);
            }
        }
        else if (Gdx.input.getX()>568&&Gdx.input.getX()<680&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
            game.batch.draw(select_tanksel,0,0,800,450);
            game.batch.draw(tanks[selection%3],500,110,252,232);
            if(Gdx.input.isTouched()) {
                game.p2Tank=selection%3;
                game.setScreen(new PvP(game));

            }
        }
//        else if (Gdx.input.getX()>120&&Gdx.input.getX()<235&&Gdx.input.getY()>370&&Gdx.input.getY()<405){
//            game.batch.draw(select_tanksel,0,0,800,450);
//            if(Gdx.input.isTouched()) {
//
//            }
//        }
        else {
            game.batch.draw(tanksel, 0, 0, 800, 450);
            game.batch.draw(tanks[selection % 3], 500, 110, 252, 232);
        }
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
